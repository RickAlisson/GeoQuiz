
function showModes() {
  container.innerHTML = `
    <h1>Selecione seu <font color="green">nível</font>.</h1>
    <a href="easy.html">
      <button>Fácil</button>
    </a>
    <a href="medium.html">
      <button>Intermediário</button>
    </a>
    <a href="hard.html">
      <button>Difícil</button>
    </a>
    
  `
}